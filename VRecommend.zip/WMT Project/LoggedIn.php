<!DOCTYPE html>
<html>	
<head>
<style>

     body{
      background-image: url("categoriesBackground.jpg");
     }



     h1 {
  font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;
  font-size: 65px;
  padding: 5px 50px;
  text-align: center;
  text-transform: uppercase;
  text-rendering: optimizeLegibility;
  text-shadow: -3px 3px white, 3px 3px white, 3px 3px white, 3px -3px white;
}
  
  
*/



form
{
text-align:right;
}

table {
  margin-left: 160px;
  width: 100%;
}


 ul{
        padding: 0;
        list-style: none;
    }
    ul li{
        width: 345px;
        display: inline-block;
        position: relative;
        text-align: center;
        line-height: 33px;
        
    }
    ul li a{
        display: block;
        padding: 5px 10px;
        color: #d19cba;
        background: #181818;
        text-decoration:none;
        font-weight:bold;
        font-size:20px;
    }
    ul li a:hover{
        color: #000000;
        background: #d19cba;
        font-weight:bold;
        font-size:20px;
    }
    ul li ul{
        display: none;
        position: absolute;
        z-index: 999;
        left: 0;
    }
    ul li:hover ul{
        display: block; 
    } 















#search5back{
    margin:0 auto;  
}

#searchbox5{
    width:200px;
    margin:0 auto;
    padding: 50px 0 30px;
    
}
#search5{
    background: url("search.png") no-repeat 10px 6px #444;
    border:0 none;
    background-color: #ffffff;
    font: bold 13px Arial, Helvetica, Sans-serif;
    color:#000000;
    width:150px;
    padding:6px 15px 6px 35px;
    border-radius:20px;
    text-shadow:0 2px 2px rgba(0,0,0,0.3);
    box-shadow:0 1px 0 rgba(255,255,255,0.1), 0 1px 3px rgba(0,0,0,0.2) inset;
    -webkit-transition: all 0.7s ease 0s;
}

#search5:focus {
    width: 200px;
    outline:0;
}










</style>

<script>
function showResult(str) {
  if (str.length==0) { 
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","livesearch.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>

 <?php
   session_start(); //starts the session
   if($_SESSION['user'])
   { // checks if the user is logged in  
   }
   else
   {
      header("location: website.php"); // redirects if user is not logged in
   }
   $user = $_SESSION['user']; //assigns user value
   ?>

<body>

<p align ="left">  <b> <font size ="5px"><font color="#181818"><a href="Logout.php"> Sign Out </a></font></font></b></p> 
<p align ="right">  <b>  <font size ="5px"> Hello ! <font color="#8A0651"> <?php Print "$user"?> </font> </font> </b>  </p>

<h1 id="elegantshadow">Vrecommend</h1>


  <div id="search5back">
<form method="get" id="searchbox5">
<input id="search5" name="q"  type="text" size="40" onkeyup="showResult(this.value)" placeholder="Search..." />
<div id="livesearch"></div>
</form>




  </div>








<table>
  <tr>
    <td>
 <ul id="Books">
         <li>
            <a href="Books.html">Books</a>
           
        </li>
        
    </ul>
</td>
    <td>
<ul>
      <li>
            <a href="Movies.html">Movies</a>
            
        </li> 
</ul>
</td>
  </tr>

 <tr>
    <td>
<ul> <li>
           <a href="#">Electronics &#9662</a>
           <ul>
               <li><a href="#">Televisions</a></li>
               <li><a href="recommend_mobilephones">Mobile Phones</a></li>
                <li><a href="#">Tablets</a></li>
               <li><a href="#">Laptops</a></li>
               <li><a href="#">Camera</a></li>
               
                  
           </ul>

      </li>
        
        
    </ul>
</td>
    <td>
<ul>
         <li>
            <a href="Restaurants.html">Restaurants</a>
            
        </li>
        
    </ul>
</td>
  </tr>
  

 
</table> 



</body>
</html>
